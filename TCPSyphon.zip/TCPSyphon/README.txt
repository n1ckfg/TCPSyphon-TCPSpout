===========
 TCPSyphon
===========

http://techlife.sg/TCPSyphon/

Special Thanks;
bangnoise (Tom Butterworth) & vade (Anton Marini)
http://syphon.v002.info

Version 1.95
	Supports thread safe in SDK.
Version 1.94
	Supports server framerate. You can set the desired sender framerate(default is 30fps).
Version 1.93
	Syphon name is added process number on client.
Version 1.92
	supports the TLRemoteCamera for Android.
Version 1.91
	supports preferences dialog. You can set manually a network port.
Version 1.90
	re-build by new SDK.
	fix reconnect function on client.
	fix server's port display.
Version 1.82
	add web-site link for new version information.
	fix bug when you select another server on client.
	supports update notification.
Version 1.81( client only )
	fix memory leak. so sorry...
Version 1.80( client only )
	fix localization problem.
Version 1.70
	supported turbo-jpeg(4:2:0 chrominance subsampling).
	http://www.libjpeg-turbo.org/About/TurboJPEG
Version 1.60
	stay menu-bar. [Thanks to suggestion by DJ Oscar Troya.]
	when re-launch, automatically try reconnecting. [Thanks to suggestion by DJ Oscar Troya.]
Version 1.50
	supported multiple instance of TCPSyphonServer on a Host.
Version 1.40
	supported multiple Syphon outputs in host application. [Thanks to suggestion by Resolume team]
Version 1.30
	fix rarely crash problem
Version 1.20
	disabled AppNap on OSX10.9
	automatically try reconnecting when disconnection.
Version 1.10
	supported PNG encode.
	fix to query IP Address.
Version 1.00
	Quick-build release


Simplified BSD license,

     Copyright 2014-2017 z37soft (Nozomu Miura). All rights reserved.
     
     Redistribution and use in source and binary forms, with or without
     modification, are permitted provided that the following conditions are met:
     
     * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
     
     * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
     
     THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
     ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
     WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
     DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS BE LIABLE FOR ANY
     DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
     LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
     ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
     (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
     SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.